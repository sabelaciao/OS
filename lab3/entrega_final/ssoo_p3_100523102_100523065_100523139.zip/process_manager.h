#ifndef PROCESS_MANAGER_H
#define PROCESS_MANAGER_H

void *process_manager(void *arg);  // Thread function declaration

#endif